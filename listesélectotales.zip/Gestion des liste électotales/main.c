#include <stdio.h>
#include "listelc.h"

int main()
{
 /*   liste l1= {12345,54321,"gauche",123,321,345,05,05,2022,"H"};
    liste l2= {58975,65943,"droite",123,321,345,05,05,2022,"H"};
    liste l3= {89005,54321,"centre",123,321,345,05,05,2022,"F"};
    int x;
x=ajouter("liste.txt", l1);
    if(x==1)
        printf("\najout de la liste avec succés\n");
    else printf("\nechec ajout");
    int x1=ajouter("liste.txt", l2);
    if(x1==1)
        printf("\najout de la liste avec succés\n");
    else printf("\nechec ajout");
    int x2=ajouter("liste.txt", l3);
    if(x2==1)
        printf("\najout de la liste avec succés\n");
    else printf("\nechec ajout");

liste l0;
    l0= chercher("liste.txt", 89005);
    if(l0.id==-1)
        printf("introuvable");
    else
	printf("id trouvé\n");

int y=modifier("liste.txt", 89005, l2 );
printf("%d",y);

int z=supprimer("liste.txt", 58975);*/

int v;
v=vote("liste.txt",12345);
tri("liste.txt","liste.txt");


return 0;
}
