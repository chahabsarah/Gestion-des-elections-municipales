#include "listelc.h"
#include <stdio.h>

//Ajout
int ajouter(char file[], liste l)
{
    
    FILE * f=fopen(file, "a");
    if(f!=NULL)
    {
        fprintf(f,"%d %d %s %d %d %d %d %d %d %s %d\n",l.id,l.idt,l.orient,l.n1,l.n2,l.n3,l.d.j,l.d.m,l.d.a,l.genre,l.nbvote);
        fclose(f);
        return 1;
    }
    else return 0;
}

//CHERCHER
liste chercher(char  file[], int id)
{
    liste l;
    int tr=0;
    FILE * f=fopen(file, "r");
    if(f!=NULL)
    {
        while(tr==0&& fscanf(f,"%d %d %s %d %d %d %d %d %d %s %d\n",&l.id,&l.idt,l.orient,&l.n1,&l.n2,&l.n3,&l.d.j,&l.d.m,&l.d.a,l.genre,&l.nbvote)!=EOF)
        {
            if(l.id== id)
                tr=1;
        }
    }
    fclose(f);
    if(tr==0)
        l.id=-1;
    return l;
}
//MODIFIER
int modifier( char  file[],int id,liste nouv )
{
    int tr=0;
    liste l;
    FILE * f=fopen(file, "r");
    FILE * f2=fopen("nouv.txt", "w");
    if(f!=NULL && f2!=NULL)
    {
        while(fscanf(f,"%d %d %s %d %d %d %d %d %d %s %d\n",&l.id,&l.idt,l.orient,&l.n1,&l.n2,&l.n3,&l.d.j,&l.d.m,&l.d.a,l.genre,&l.nbvote)!=EOF)
        {
            if(l.id== id)
            {
                fprintf(f2,"%d %d %s %d %d %d %d %d %d %s %d\n",nouv.id,nouv.idt,nouv.orient,nouv.n1,nouv.n2,nouv.n3,nouv.d.j,nouv.d.m,nouv.d.a,nouv.genre,nouv.nbvote);
                tr=1;
            }
            else
                fprintf(f2,"%d %d %s %d %d %d %d %d %d %s %d\n",l.id,l.idt,l.orient,l.n1,l.n2,l.n3,l.d.j,l.d.m,l.d.a,l.genre,l.nbvote);

        }
    }
    fclose(f);
    fclose(f2);
    remove(file);
    rename("nouv.txt", file);
    return tr;

}

//SUPPRIMER
int supprimer(char file[], int id)
{
    int tr=0;
    liste l;
    FILE * f=fopen(file, "r");
    FILE * f2=fopen("nouv.txt", "w");
    if(f!=NULL && f2!=NULL)
    {
        while(fscanf(f,"%d %d %s %d %d %d %d %d %d %s %d\n",&l.id,&l.idt,l.orient,&l.n1,&l.n2,&l.n3,&l.d.j,&l.d.m,&l.d.a,l.genre,&l.nbvote)!=EOF)
        {
            if(l.id== id)
                tr=1;
            else
                fprintf(f2,"%d %d %s %d %d %d %d %d %d %s %d\n",l.id,l.idt,l.orient,l.n1,l.n2,l.n3,l.d.j,l.d.m,l.d.a,l.genre,l.nbvote);
        }
    }
    fclose(f);
    fclose(f2);
    remove(file);
    rename("nouv.txt", file);
    return tr;
}

//VOTE
int vote(char file[], int id)
{
    int nbv;
    liste l;
    FILE * f=fopen(file, "a");
    if(f!=NULL)
	{
		while(fscanf(f,"%d %d %s %d %d %d %d %d %d %s %d\n",&l.id,&l.idt,l.orient,&l.n1,&l.n2,&l.n3,&l.d.j,&l.d.m,&l.d.a,l.genre,&l.nbvote)!=EOF)
			{
				if(id==l.id){
					nbv++;
					l.nbvote++;
					}
						}
							}
							
	fclose(f);
	return nbv;


}

//TRI

void tri(char file1[],char file2[])
{
liste tab[100];
int min,n=0;
liste l,temp;
FILE * f;
f=fopen(file1, "r+");
if (f!=NULL)
{
  while(fscanf(f,"%d %d %s %d %d %d %d %d %d %s %d\n",&l.id,&l.idt,l.orient,&l.n1,&l.n2,&l.n3,&l.d.j,&l.d.m,&l.d.a,l.genre,&l.nbvote)!=EOF)
  {
      tab[n]=l;
      n++;
}
}
fclose(f);

for(int i=0;i<n-1;i++)
{
min=i;
for(int j=i+1;j<n;j++)
{
if(vote(file2,tab[min].id)>vote(file2,tab[j].id))
min=j;
}
if(min!=i)
{
temp=tab[i];
tab[i]=tab[min];
tab[min]=temp;
}}
f=fopen("sorted.txt","a+");
for(int i=0 ;i<n;i++){
    if(f!=NULL)
   {
        l=tab[i];
	fprintf(f,"%d %d %s %d %d %d %d %d %d %s %d\n",l.id,l.idt,l.orient,l.n1,l.n2,l.n3,l.d.j,l.d.m,l.d.a,l.genre,l.nbvote);}
}
fclose(f);
}
	


