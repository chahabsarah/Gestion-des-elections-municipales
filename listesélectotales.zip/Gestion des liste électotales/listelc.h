#ifndef LISTELC_H_INCLUDED
#define LISTELC_H_INCLUDED


typedef struct{
    int j;
    int m;
    int a;
    }date;

typedef struct{
    int id;
    int idt;
    char orient[20];
    int n1;
    int n2;
    int n3;
    date d;
    char genre[20];
    int nbvote;
    }liste;


int ajouter(char *fich,liste l);
int modifier(char *fich,int id,liste nouv);
int supprimer(char *fich,int id);
liste chercher(char *fich,int id);
int vote(char file[], int id);
void tri(char file1[],char file2[]);


#endif // LISTELC_H_INCLUDED








